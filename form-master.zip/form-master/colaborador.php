<?php

require_once 'classes/Colaborador.class.php';
require_once 'classes/Funcoes.class.php';

$objFcn = new Colaborador();
$objFcs = new Funcoes();

if(isset($_POST['btCadastrar'])){
    if($objFcn->queryInsert($_POST) == 'ok'){
        header('location: /colaborador.php');
    }else{
        echo '<script type="text/javascript">alert("Erro em cadastrar");</script>';
    }
}

if(isset($_POST['btAlterar'])){
    if($objFcn->queryUpdate($_POST) == 'ok'){
        header('location: ?acao=edit&idColaborador='.$objFcs->base64($_POST['idColaborador'],1));
    }else{
        echo '<script type="text/javascript">alert("Erro em alterar");</script>';
    }
}


if(isset($_GET['acao'])){
    switch($_GET['acao']){
        case 'edit': $func = $objFcn->querySeleciona($_GET['idColaborador']); break;
        case 'delet':
            if($objFcn->queryDelete($_GET['idColaborador']) == 'ok'){
                header('location: /colaborador.php');
            }else{
                echo '<script type="text/javascript">alert("Erro em deletar");</script>';
            }
                break;
    }
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>  
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
      <link rel="stylesheet" type="text/css" href="css/estilo.css">
    <title>Colaborador</title>
</head>
<body>

<body>
<div class="container-fluid">
    <div class="row">
        <div id="relatorio">
            <div class="card">
                <div class="card-header">
                    Colaborador
                </div>
            <div class="card-body">
                <blockquote class="blockquote mb-0">
    
                        <div id="formulario">
                            <form name="formCad" action="" method="post">
                                <div class="form-group">
                            	   <label>Nome:</label><br>
                                    <input type="text" class="form-group" name="nome_colaborador" required="required" value="<?=$objFcs->tratarCaracter((isset($func['nome_colaborador']))?($func['nome_colaborador']):(''), 2)?>"><br>
                                </div>
                                <div class="form-group">
                                    <label>Senha: </label><br>
                                    <input type="password" class="form-group" name="senha_colaborador" required="required" value="<?=$objFcs->tratarCaracter((isset($func['senha_colaborador']))?($func['senha_colaborador']):(''), 2)?>"><br>
                                </div>
                                <a href='site.php'><button type='button' class='btn btn-danger btn-sm'>Voltar</button></a>
                                <input type="submit" class="btn btn-primary btn-sm" name="<?=(isset($_GET['acao']) == 'edit')?('btAlterar'):('btCadastrar')?>" value="<?=(isset($_GET['acao']) == 'edit')?('Alterar'):('Cadastrar')?>">
                                <input type="hidden" name="idColaborador" value="<?=(isset($func['idColaborador']))?($objFcs->base64($func['idColaborador'], 1)):('')?>">
                            </form>
                        </div>    
                    </blockquote>       
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        </br>
    </div>
    <div class="row">
        <div id="relatorio">
            <div class="card">
                <div class="card-header">
                    Colaboradores cadastrados
                </div>
            <div class="card-body">
                <blockquote class="blockquote mb-0">
            
                    <div class="colaborador">
                    
                    <table class="table table-hover">
                      <thead>
                        <tr>
                            <th scope="col">Nome</th>
                            <th scope="col">Editar</th>
                            <th scope="col">Apagar</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach($objFcn->querySelect() as $rst){ ?>
                            <tr>
                              <th scope="row"><div class="nome_colaborador"><?=$objFcs->tratarCaracter($rst['nome_colaborador'], 2)?></div></th>
                              <td><div class="editar"><a href="?acao=edit&idColaborador=<?=$objFcs->base64($rst['idColaborador'], 1)?>" title="Editar dados"><img src="img/ico-editar.png" width="16" height="16" alt="Editar"></a></div></td>
                              <td><div class="excluir"><a href="?acao=delet&idCliente=<?=$objFcs->base64($rst['idColaborador'], 1)?>" title="Excluir esse dado"><img src="img/ico-excluir.png" width="16" height="16" alt="Excluir"></a></div></td>
                            </tr>
                        <?php } ?>
                        </tbody>
                    </table>
                </div>
            
                </blockquote>       
            </div>
        </div>
        </div>
    </div>
</div> 
</body>
</html>
