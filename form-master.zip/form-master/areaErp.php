<!DOCTYPE html>
<html lang="pt-BR">
<head>  
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
      <link rel="stylesheet" type="text/css" href="css/estilo.css">
    <title>Autenticação de acesso para o colaborador</title>
</head>
<body background="img/fundo.jpg" bgproperties="fixed">
<div class="container">
	<div class="row justify-content-md-center align-items-center">
		<div id="box">
		<div class="col-md-auto">	
			<div class="card text-center" style="width: 18rem;">
			  <div class="card-header">
			    Autenticação de acesso 
			  </div>
			  <div class="card-body">
			    <h5 class="card-title">Sistema</h5>
			    <form method="post" action="ope.php" id="formlogin" name="formlogin" >
						<label>Nome: </label>
						<input type="text" name="nome_colaborador" id="nome_colaborador"/><br/>
						<label>Senha:</label>
						<input type="password" name="senha_colaborador" id="senha_colaborador"/><br/>
						<a href='index.php'><button type='button' class='btn btn-danger btn-sm'>Voltar</button></a>
						<input type="submit" value="Entrar" class="btn btn-success btn-sm"/>
				</form>
			  </div>
			</div>
		</div>
	</div>
</div>
</div>
</body>
</html>