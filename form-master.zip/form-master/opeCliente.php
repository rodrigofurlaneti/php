<?php 
session_start();
$telefone_cliente = $_POST['telefone_cliente'];
$senha_cliente = $_POST['senha_cliente'];
$con = mysql_connect("127.0.0.1:49277", "azure", "6#vWHD_$") or die ("Sem conexão com o servidor");
$select = mysql_select_db("localdb") or die("Sem acesso ao DB, Entre em contato com o Administrador, rodrigofurlaneti31@hotmail.com");
$result = mysql_query("SELECT * FROM `cliente` WHERE `telefone_cliente` = '$telefone_cliente' AND `senha_cliente`= '$senha_cliente'");

if(mysql_num_rows ($result) > 0 )
{
	$_SESSION['telefone_cliente'] = $telefone_cliente;
	$_SESSION['senha_cliente'] = $senha_cliente;
	header('location:siteCliente.php');
}
else{
    unset ($_SESSION['telefone_cliente']);
    unset ($_SESSION['senha_cliente']);
    header('location:areaCliente.php');
    }
?>
