<!DOCTYPE html>
<html lang="pt-BR">
<head>  
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
      <link rel="stylesheet" type="text/css" href="css/estilo.css">
    <title>Cadastrar cliente</title>
</head>
<?php 
  session_start();
  if((!isset ($_SESSION['telefone_cliente']) == true) and (!isset ($_SESSION['senha_cliente']) == true))
  {
    unset($_SESSION['telefone_cliente']);
    unset($_SESSION['senha_cliente']);
    header('location:index.php');
  }
  ?>

  <body>
    <div class="media">
      <div class="media-body">
        <h5 class="mt-0 mb-1">Resturante</h5>
      </div>

      <img class="ml-3" src="img/usuario.png">
    </div>
      <nav class="navbar navbar-light" style="background-color: #e3f2fd;">
        <a class="navbar-brand" href="pedidoCliente.php">Pedido</a>
      </nav>

  </body>
</html>
