<?php

include_once "Conexao.class.php";
include_once "Funcoes.class.php";

class Estoque {
    
    private $con;
    private $objfc;
    private $idEstoque;
    private $id_produto_estoque;
    private $quantidade_estoque;
    private $colaborador_estoque;
    
    public function __construct(){
        $this->con = new Conexao();
        $this->objfc = new Funcoes();
    }
    
    public function __set($atributo, $valor){
        $this->$atributo = $valor;
    }
    public function __get($atributo){
        return $this->$atributo;
    }
    
    public function querySeleciona($dado){
        try{
            $this->idEstoque = $this->objfc->base64($dado, 2);
            $cst = $this->con->conectar()->prepare("SELECT idEstoque, id_produto_estoque, quantidade_estoque, colaborador_estoque, FROM `estoque` WHERE `idEstoque` = :idEstoque;");
            $cst->bindParam(":idEstoque", $this->idEstoque, PDO::PARAM_INT);
            $cst->execute();
            return $cst->fetch();
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function querySelect(){
        try{
            $cst = $this->con->conectar()->prepare("SELECT `idEstoque`, `id_produto_estoque`, `quantidade_estoque`, `colaborador_estoque`FROM `estoque`;");
            $cst->execute();
            return $cst->fetchAll();
        } catch (PDOException $ex) {
            return 'erro '.$ex->getMessage();
        }
    }
    
    public function queryInsert($dados){
        try{
            $this->id_produto_estoque         = $this->objfc->tratarCaracter($dados['id_produto_estoque'], 1);
            $this->quantidade_estoque         = $this->objfc->tratarCaracter($dados['quantidade_estoque'], 1);
            $this->colaborador_estoque        = $this->objfc->tratarCaracter($dados['colaborador_estoque'], 1);
            $cst = $this->con->conectar()->prepare("INSERT INTO `estoque` (`id_produto_estoque`, `quantidade_estoque`, `colaborador_estoque`) VALUES (:id_produto_estoque, :quantidade_estoque, :colaborador_estoque);");
            $cst->bindParam(":id_produto_estoque",  $this->id_produto_estoque, PDO::PARAM_STR);
            $cst->bindParam(":quantidade_estoque",  $this->quantidade_estoque, PDO::PARAM_STR);
            $cst->bindParam(":colaborador_estoque", $this->colaborador_estoque, PDO::PARAM_STR);
            
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function queryUpdate($dados){
        try{
            $this->idEstoque            = $this->objfc->base64($dados['idEstoque'], 2);
            $this->id_produto_estoque   = $this->objfc->tratarCaracter($dados['id_produto_estoque'], 1);
            $this->quantidade_estoque   = $this->objfc->tratarCaracter($dados['quantidade_estoque'], 1);
            $this->colaborador_estoque  = $this->objfc->tratarCaracter($dados['colaborador_estoque'], 1);
            $cst = $this->con->conectar()->prepare("UPDATE `estoque` SET `id_produto_estoque` = :produto_estoque, `quantidade_estoque` = :quantidade_estoque, `colaborador_estoque` = :colaborador_estoque WHERE `idEstoque` = :idEstoque;");
            $cst->bindParam(":id_produto_estoque",      $this->id_produto_estoque, PDO::PARAM_STR);
            $cst->bindParam(":quantidade_estoque",      $this->quantidade_estoque, PDO::PARAM_STR);
            $cst->bindParam(":colaborador_estoque",     $this->colaborador_estoque, PDO::PARAM_STR);
            
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function queryDelete($dado){
        try{
            $this->idEstoque = $this->objfc->base64($dado, 2);
            $cst = $this->con->conectar()->prepare("DELETE FROM `estoque` WHERE `idEstoque` = :idEstoque;");
            $cst->bindParam(":idEstoque", $this->idEstoque, PDO::PARAM_INT);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error'.$ex->getMessage();
        }
    }
    
}

?>
