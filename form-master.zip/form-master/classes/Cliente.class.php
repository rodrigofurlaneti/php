<?php

include_once "Conexao.class.php";
include_once "Funcoes.class.php";

class Cliente {
    
    private $con;
    private $objfc;
    private $idCliente;
    private $nome_cliente;
    private $endereco_cliente;
    private $telefone_cliente;
    private $senha_cliente;
    private $colaborador_cliente;
    
    public function __construct(){
        $this->con = new Conexao();
        $this->objfc = new Funcoes();
    }
    
    public function __set($atributo, $valor){
        $this->$atributo = $valor;
    }
    public function __get($atributo){
        return $this->$atributo;
    }
    
    public function querySeleciona($dado){
        try{
            $this->idCliente = $this->objfc->base64($dado, 2);
            $cst = $this->con->conectar()->prepare("SELECT idCliente, nome_cliente, endereco_cliente, telefone_cliente, senha_cliente , `colaborador_cliente`  FROM `cliente` WHERE `idCliente` = :idCliente;");
            $cst->bindParam(":idCliente", $this->idCliente, PDO::PARAM_INT);
            $cst->execute();
            return $cst->fetch();
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function querySelect(){
        try{
            $cst = $this->con->conectar()->prepare("SELECT `idCliente`, `nome_cliente`, `endereco_cliente`, `telefone_cliente` , `colaborador_cliente` FROM `cliente`;");
            $cst->execute();
            return $cst->fetchAll();
        } catch (PDOException $ex) {
            return 'erro '.$ex->getMessage();
        }
    }
    
    public function queryInsert($dados){
        try{
            $this->nome_cliente = $this->objfc->tratarCaracter($dados['nome_cliente'], 1);
            $this->endereco_cliente = $this->objfc->tratarCaracter($dados['endereco_cliente'], 1);
            $this->telefone_cliente = $this->objfc->tratarCaracter($dados['telefone_cliente'], 1);
            $this->senha_cliente = $this->objfc->tratarCaracter($dados['senha_cliente'], 1);
            $this->colaborador_cliente = $this->objfc->tratarCaracter($dados['colaborador_cliente'], 1);
            $cst = $this->con->conectar()->prepare("INSERT INTO `cliente` (`nome_cliente`, `endereco_cliente`, `telefone_cliente`, `senha_cliente`, `colaborador_cliente`) VALUES (:nome_cliente, :endereco_cliente, :telefone_cliente, :senha_cliente, :colaborador_cliente);");
            $cst->bindParam(":nome_cliente", $this->nome_cliente, PDO::PARAM_STR);
            $cst->bindParam(":endereco_cliente", $this->endereco_cliente, PDO::PARAM_STR);
            $cst->bindParam(":telefone_cliente", $this->telefone_cliente, PDO::PARAM_STR);
            $cst->bindParam(":senha_cliente", $this->senha_cliente, PDO::PARAM_STR);
            $cst->bindParam(":colaborador_cliente", $this->colaborador_cliente, PDO::PARAM_STR);
            
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function queryUpdate($dados){
        try{
            $this->idCliente = $this->objfc->base64($dados['idCliente'], 2);
            $this->nome_cliente = $this->objfc->tratarCaracter($dados['nome_cliente'], 1);
            $this->endereco_cliente = $this->objfc->tratarCaracter($dados['endereco_cliente'], 1);
            $this->telefone_cliente = $this->objfc->tratarCaracter($dados['telefone_cliente'], 1);
            $this->senha_cliente = $this->objfc->tratarCaracter($dados['senha_cliente'], 1);
            $this->colaborador_cliente = $this->objfc->tratarCaracter($dados['colaborador_cliente'], 1);
            $cst = $this->con->conectar()->prepare("UPDATE `cliente` SET  `nome_cliente` = :nome_cliente, `endereco_cliente` = :endereco_cliente, `telefone_cliente` = :telefone_cliente, `senha_cliente` = :senha_cliente, `colaborador_cliente` = :colaborador_cliente WHERE `idCliente` = :idCliente;");
            $cst->bindParam(":idCliente", $this->idCliente, PDO::PARAM_INT);
            $cst->bindParam(":nome_cliente", $this->nome_cliente, PDO::PARAM_STR);
            $cst->bindParam(":endereco_cliente", $this->endereco_cliente, PDO::PARAM_STR);
            $cst->bindParam(":telefone_cliente", $this->telefone_cliente, PDO::PARAM_STR);
            $cst->bindParam(":senha_cliente", $this->senha_cliente, PDO::PARAM_STR);
            $cst->bindParam(":colaborador_cliente", $this->colaborador_cliente, PDO::PARAM_STR);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function queryDelete($dado){
        try{
            $this->idCliente = $this->objfc->base64($dado, 2);
            $cst = $this->con->conectar()->prepare("DELETE FROM `cliente` WHERE `idCliente` = :idCliente;");
            $cst->bindParam(":idCliente", $this->idCliente, PDO::PARAM_INT);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error'.$ex->getMessage();
        }
    }
    
}

?>
