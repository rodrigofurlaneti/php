<?php
date_default_timezone_set('America/Sao_Paulo');
include_once "Conexao.class.php";
include_once "Funcoes.class.php";

class Pedido {
    
    private $con;
    private $objfc;
    private $idPedido;
    private $idCliente;
    private $valor_total_pedido;
    private $data_hora_pedido;
    private $registro_pedido;
    private $idPedido_pedidoitem;
    private $id_pedido_pedidoitem;
    private $id_produto_pedidoitem;
    private $quantidade_pedidoitem;
    private $valor_parcial_pedidoitem;
    private $solicitante_pedidoitem;
    private $data_hora_pedidoitem;
    

    public function __construct(){
        $this->con = new Conexao();
        $this->objfc = new Funcoes();
    }
    
    public function __set($atributo, $valor){
        $this->$atributo = $valor;
    }
    public function __get($atributo){
        return $this->$atributo;
    }
    
    public function querySeleciona($dado){
        try{
            $this->idPedido = $this->objfc->tratarCaracter($dado['idPedido'], 1);
            $cst = $this->con->conectar()->prepare("SELECT * FROM `pedido` WHERE `idPedido` = :idPedido;");
            $cst->bindParam(":idPedido", $this->idPedido, PDO::PARAM_INT);
            $cst->execute();
            return $cst->fetch();
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function querySelect(){
        try{
            $cst = $this->con->conectar()->prepare("SELECT `idPedido`, `cliente_pedido` FROM `pedido`;");
            $cst->execute();
            return $cst->fetchAll();
        } catch (PDOException $ex) {
            return 'erro '.$ex->getMessage();
        }
    }
    
    public function queryInsert($dados){
        try{

            $this->idCliente            = $this->objfc->tratarCaracter($dados['idCliente'], 1);
            $this->valor_total_pedido   = $this->objfc->tratarCaracter($dados['valor_total_pedido'], 1);
            $this->data_hora_pedido     = $this->objfc->tratarCaracter($dados['data_hora_pedido'], 1);
            $this->registro_pedido     = $this->objfc->tratarCaracter($dados['registro_pedido'], 1);

            $cst = $this->con->conectar()->prepare("INSERT INTO `pedido` (`idCliente`, `valor_total_pedido`, `data_hora_pedido`, `registro_pedido`) VALUES (:idCliente, :valor_total_pedido, :data_hora_pedido, :registro_pedido);");
            $cst->bindParam(":idCliente", $this->idCliente, PDO::PARAM_STR);
            $cst->bindParam(":valor_total_pedido", $this->valor_total_pedido, PDO::PARAM_STR);
            $cst->bindParam(":data_hora_pedido", $this->data_hora_pedido, PDO::PARAM_STR);
            $cst->bindParam(":registro_pedido", $this->registro_pedido, PDO::PARAM_STR);
            
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function queryUpdate($dados){
        try{
            $this->id_pedido_pedidoitem      = $this->objfc->tratarCaracter($dados['id_pedido_pedidoitem'], 1);
            $this->id_produto_pedidoitem     = $this->objfc->tratarCaracter($dados['id_produto_pedidoitem'], 1);
            $this->quantidade_pedidoitem     = $this->objfc->tratarCaracter($dados['quantidade_pedidoitem'], 1);
            $this->valor_parcial_pedidoitem  = $this->objfc->tratarCaracter($dados['valor_parcial_pedidoitem'], 1);
            $this->solicitante_pedidoitem    = $this->objfc->tratarCaracter($dados['solicitante_pedidoitem'], 1);
            $this->data_hora_pedidoitem      = $this->objfc->tratarCaracter($dados['data_hora_pedidoitem'], 1);
                        

            $cst = $this->con->conectar()->prepare("INSERT INTO `pedidoitem` (`id_pedido_pedidoitem`, `id_produto_pedidoitem`, `quantidade_pedidoitem`, `valor_parcial_pedidoitem`, `solicitante_pedidoitem`, `data_hora_pedidoitem`) VALUES (:id_pedido_pedidoitem, :id_produto_pedidoitem, :quantidade_pedidoitem, :valor_parcial_pedidoitem, :solicitante_pedidoitem, :data_hora_pedidoitem);");

            $cst->bindParam(":id_pedido_pedidoitem",       $this->id_pedido_pedidoitem, PDO::PARAM_STR);
            $cst->bindParam(":id_produto_pedidoitem",       $this->id_produto_pedidoitem, PDO::PARAM_STR);
            $cst->bindParam(":quantidade_pedidoitem",    $this->quantidade_pedidoitem, PDO::PARAM_STR);
            $cst->bindParam(":valor_parcial_pedidoitem",   $this->valor_parcial_pedidoitem, PDO::PARAM_STR);
            $cst->bindParam(":solicitante_pedidoitem",   $this->solicitante_pedidoitem, PDO::PARAM_STR);
            $cst->bindParam(":data_hora_pedidoitem",   $this->data_hora_pedidoitem, PDO::PARAM_STR);
           

            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function queryDelete($dado){
        try{
            $this->idPedido = $this->objfc->tratarCaracter($dado['idPedido'], 1);
            $cst = $this->con->conectar()->prepare("DELETE FROM `pedido` WHERE `idPedido` = :idPedido;");
            $cst->bindParam(":idPedido", $this->idPedido, PDO::PARAM_INT);

            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error'.$ex->getMessage();
        }
    }

    public function queryInsertPedidoItem($dados){
        try{
            $this->id_pedido_pedidoitem      = $this->objfc->tratarCaracter($dados['id_pedido_pedidoitem'], 1);
            $this->id_produto_pedidoitem     = $this->objfc->tratarCaracter($dados['id_produto_pedidoitem'], 1);
            $this->quantidade_pedidoitem     = $this->objfc->tratarCaracter($dados['quantidade_pedidoitem'], 1);
            $this->valor_parcial_pedidoitem  = $this->objfc->tratarCaracter($dados['valor_parcial_pedidoitem'], 1);
            $this->solicitante_pedidoitem    = $this->objfc->tratarCaracter($dados['solicitante_pedidoitem'], 1);
            $this->data_hora_pedidoitem      = $this->objfc->tratarCaracter($dados['data_hora_pedidoitem'], 1);
            
            $cst = $this->con->conectar()->prepare("INSERT INTO `pedidoitem` (`id_pedido_pedidoitem`, `id_produto_pedidoitem`, `quantidade_pedidoitem`, `valor_parcial_pedidoitem`, `solicitante_pedidoitem`, `data_hora_pedidoitem`) VALUES (:id_pedido_pedidoitem, :id_produto_pedidoitem, :quantidade_pedidoitem, :valor_parcial_pedidoitem, :solicitante_pedidoitem, :data_hora_pedidoitem);");

            $cst->bindParam(":id_pedido_pedidoitem", $this->id_pedido_pedidoitem, PDO::PARAM_STR);
            $cst->bindParam(":id_produto_pedidoitem", $this->id_produto_pedidoitem, PDO::PARAM_STR);
            $cst->bindParam(":quantidade_pedidoitem", $this->quantidade_pedidoitem, PDO::PARAM_STR);
            $cst->bindParam(":valor_parcial_pedidoitem", $this->valor_parcial_pedidoitem, PDO::PARAM_STR);
            $cst->bindParam(":solicitante_pedidoitem",$this->solicitante_pedidoitem, PDO::PARAM_STR);
            $cst->bindParam(":data_hora_pedidoitem", $this->data_hora_pedidoitem, PDO::PARAM_STR);

            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        }catch (PDOException $ex){
            return 'error '.$ex->getMessage();
        }
    }

    public function querySelectPedidoItem($dado){
        try{
            $this->cliente_pedido = $this->objfc->tratarCaracter($dado, 2);
            echo $this->cliente_pedido;
            die();
            $cst = $this->con->conectar()->prepare("SELECT * FROM `pedido` INNER JOIN `pedidoitem` ON `pedido.idPedido` = `pedidoitem.idPedidoItem` INNER JOIN `cliente` ON `cliente.nome_cliente` = `pedido.cliente_pedido` WHERE `pedido.cliente_pedido` = :cliente_pedido;");
            $cst->bindParam(":cliente_pedido", $this->cliente_pedido, PDO::PARAM_INT);
            $cst->execute();
            return $cst->fetchAll();
        } catch (PDOException $ex) {
            return 'erro '.$ex->getMessage();
        }
    }

}

?>
