<?php

include_once "Conexao.class.php";
include_once "Funcoes.class.php";

class Grupo {
    
    private $con;
    private $objfc;
    private $idGrupo;
    private $nome_grupo;
    private $colaborador_grupo;
    
    public function __construct(){
        $this->con = new Conexao();
        $this->objfc = new Funcoes();
    }
    
    public function __set($atributo, $valor){
        $this->$atributo = $valor;
    }
    public function __get($atributo){
        return $this->$atributo;
    }
    
    public function querySeleciona($dado){
        try{
            $this->idGrupo = $this->objfc->base64($dado, 2);
            $cst = $this->con->conectar()->prepare("SELECT idGrupo, nome_grupo, colaborador_grupo  FROM `grupo` WHERE `idGrupo` = :idGrupo;");
            $cst->bindParam(":idGrupo", $this->idGrupo, PDO::PARAM_INT);
            $cst->execute();
            return $cst->fetch();
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function querySelect(){
        try{
            $cst = $this->con->conectar()->prepare("SELECT `idGrupo`, `nome_grupo`, `colaborador_grupo` FROM `grupo`;");
            $cst->execute();
            return $cst->fetchAll();
        } catch (PDOException $ex) {
            return 'erro '.$ex->getMessage();
        }
    }
    
    public function queryInsert($dados){
        try{
            $this->nome_grupo = $this->objfc->tratarCaracter($dados['nome_grupo'], 1);
            $this->colaborador_grupo = $this->objfc->tratarCaracter($dados['colaborador_grupo'], 1);
            $cst = $this->con->conectar()->prepare("INSERT INTO `grupo` (`nome_grupo`, `colaborador_grupo`) VALUES (:nome_grupo, :colaborador_grupo);");
            $cst->bindParam(":nome_grupo", $this->nome_grupo, PDO::PARAM_STR);
            $cst->bindParam(":colaborador_grupo", $this->colaborador_grupo, PDO::PARAM_STR);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function queryUpdate($dados){
        try{
            $this->idGrupo = $this->objfc->base64($dados['idGrupo'], 2);
            $this->nome_grupo = $this->objfc->tratarCaracter($dados['nome_grupo'], 1);
            $this->colaborador_grupo = $this->objfc->tratarCaracter($dados['colaborador_grupo'], 1);
            $cst = $this->con->conectar()->prepare("UPDATE `grupo` SET  `nome_grupo` = :nome_grupo, `colaborador_grupo` = :colaborador_grupo WHERE `idGrupo` = :idGrupo;");
            $cst->bindParam(":idGrupo", $this->idGrupo, PDO::PARAM_INT);
            $cst->bindParam(":nome_grupo", $this->nome_grupo, PDO::PARAM_STR);
            $cst->bindParam(":colaborador_grupo", $this->colaborador_grupo, PDO::PARAM_STR);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function queryDelete($dado){
        try{
            $this->idGrupo = $this->objfc->base64($dado, 2);
            $cst = $this->con->conectar()->prepare("DELETE FROM `grupo` WHERE `idGrupo` = :idGrupo;");
            $cst->bindParam(":idGrupo", $this->idGrupo, PDO::PARAM_INT);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error'.$ex->getMessage();
        }
    }
    
}

?>
