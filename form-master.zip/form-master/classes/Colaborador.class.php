<?php

include_once "Conexao.class.php";
include_once "Funcoes.class.php";

class Colaborador {
    
    private $con;
    private $objfc;
    private $idColaborador;
    private $nome_colaborador;
    private $senha_colaborador;
    
    public function __construct(){
        $this->con = new Conexao();
        $this->objfc = new Funcoes();
    }
    
    public function __set($atributo, $valor){
        $this->$atributo = $valor;
    }
    public function __get($atributo){
        return $this->$atributo;
    }
    
    public function querySeleciona($dado){
        try{
            $this->idColaborador = $this->objfc->base64($dado, 2);
            $cst = $this->con->conectar()->prepare("SELECT idColaborador, nome_colaborador, senha_colaborador FROM `colaborador` WHERE `idColaborador` = :idColaborador;");
            $cst->bindParam(":idColaborador", $this->idColaborador, PDO::PARAM_INT);
            $cst->execute();
            return $cst->fetch();
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function querySelect(){
        try{
            $cst = $this->con->conectar()->prepare("SELECT `idColaborador`, `nome_colaborador`, `senha_colaborador` FROM `colaborador`;");
            $cst->execute();
            return $cst->fetchAll();
        } catch (PDOException $ex) {
            return 'erro '.$ex->getMessage();
        }
    }
    
    public function queryInsert($dados){
        try{
            $this->nome_colaborador = $this->objfc->tratarCaracter($dados['nome_colaborador'], 1);
            $this->senha_colaborador = $this->objfc->tratarCaracter($dados['senha_colaborador'], 1);
            $cst = $this->con->conectar()->prepare("INSERT INTO `colaborador` (`nome_colaborador`, `senha_colaborador`) VALUES (:nome_colaborador, :senha_colaborador);");
            $cst->bindParam(":nome_colaborador", $this->nome_colaborador, PDO::PARAM_STR);
            $cst->bindParam(":senha_colaborador", $this->senha_colaborador, PDO::PARAM_STR);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function queryUpdate($dados){
        try{
            $this->idColaborador = $this->objfc->base64($dados['idColaborador'], 2);
            $this->nome_colaborador = $this->objfc->tratarCaracter($dados['nome_colaborador'], 1);
            $this->senha_colaborador = $this->objfc->tratarCaracter($dados['senha_colaborador'], 1);
            $cst = $this->con->conectar()->prepare("UPDATE `colaborador` SET  `nome_colaborador` = :nome_colaborador, `senha_colaborador` = :senha_colaborador WHERE `idColaborador` = :idColaborador;");
            $cst->bindParam(":idColaborador", $this->idColaborador, PDO::PARAM_INT);
            $cst->bindParam(":nome_colaborador", $this->nome_colaborador, PDO::PARAM_STR);
            $cst->bindParam(":senha_colaborador", $this->senha_colaborador, PDO::PARAM_STR);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function queryDelete($dado){
        try{
            $this->idColaborador = $this->objfc->base64($dado, 2);
            $cst = $this->con->conectar()->prepare("DELETE FROM `colaborador` WHERE `idColaborador` = :idColaborador;");
            $cst->bindParam(":idColaborador", $this->idColaborador, PDO::PARAM_INT);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error'.$ex->getMessage();
        }
    }
    
}

?>
