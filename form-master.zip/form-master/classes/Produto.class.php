<?php

include_once "Conexao.class.php";
include_once "Funcoes.class.php";

class Produto {
    
    private $con;
    private $objfc;
    private $idProduto;
    private $grupo_produto;
    private $nome_produto;
    private $valor_produto;
    private $colaborador_produto;
    
    public function __construct(){
        $this->con = new Conexao();
        $this->objfc = new Funcoes();
    }
    
    public function __set($atributo, $valor){
        $this->$atributo = $valor;
    }
    public function __get($atributo){
        return $this->$atributo;
    }
    
    public function querySeleciona($dado){
        try{
            $this->idProduto = $this->objfc->base64($dado, 2);
            $cst = $this->con->conectar()->prepare("SELECT idProduto, grupo_produto, nome_produto, valor_produto, colaborador_produto FROM `produto` WHERE `idProduto` = :idProduto;");
            $cst->bindParam(":idProduto", $this->idProduto, PDO::PARAM_INT);
            $cst->execute();
            return $cst->fetch();
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function querySelect(){
        try{
            $cst = $this->con->conectar()->prepare("SELECT `idProduto`, `grupo_produto`, `nome_produto`, `valor_produto`, `colaborador_produto` FROM `produto`;");
            $cst->execute();
            return $cst->fetchAll();
        } catch (PDOException $ex) {
            return 'erro '.$ex->getMessage();
        }
    }
    
    public function queryInsert($dados){
        try{
            $this->grupo_produto        = $this->objfc->tratarCaracter($dados['grupo_produto'], 1);
            $this->nome_produto         = $this->objfc->tratarCaracter($dados['nome_produto'], 1);
            $this->valor_produto        = $this->objfc->tratarCaracter($dados['valor_produto'], 1);
            $this->colaborador_produto  = $this->objfc->tratarCaracter($dados['colaborador_produto'], 1);
            $cst = $this->con->conectar()->prepare("INSERT INTO `produto` (`grupo_produto`, `nome_produto`, `valor_produto`, `colaborador_produto`) VALUES (:grupo_produto, :nome_produto, :valor_produto, :colaborador_produto);");
            $cst->bindParam(":grupo_produto",       $this->grupo_produto, PDO::PARAM_STR);
            $cst->bindParam(":nome_produto",        $this->nome_produto, PDO::PARAM_STR);
            $cst->bindParam(":valor_produto",       $this->valor_produto, PDO::PARAM_STR);
            $cst->bindParam(":colaborador_produto", $this->colaborador_produto, PDO::PARAM_STR);
            
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function queryUpdate($dados){
        try{
            $this->idProduto            = $this->objfc->base64($dados['idProduto'], 2);
            $this->grupo_produto        = $this->objfc->tratarCaracter($dados['grupo_produto'], 1);
            $this->nome_produto         = $this->objfc->tratarCaracter($dados['nome_produto'], 1);
            $this->valor_produto        = $this->objfc->tratarCaracter($dados['valor_produto'], 1);
            $this->colaborador_produto  = $this->objfc->tratarCaracter($dados['colaborador_produto'], 1);
            $cst = $this->con->conectar()->prepare("UPDATE `produto` SET `grupo_produto` = :grupo_produto, `nome_produto` = :nome_produto, `valor_produto` = :valor_produto, `colaborador_produto` = :colaborador_produto WHERE `idProduto` = :idProduto;");
            $cst->bindParam(":grupo_produto",       $this->grupo_produto, PDO::PARAM_STR);
            $cst->bindParam(":nome_produto",        $this->nome_produto, PDO::PARAM_STR);
            $cst->bindParam(":valor_produto",       $this->valor_produto, PDO::PARAM_STR);
            $cst->bindParam(":colaborador_produto", $this->colaborador_produto, PDO::PARAM_STR);
            
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function queryDelete($dado){
        try{
            $this->idProduto = $this->objfc->base64($dado, 2);
            $cst = $this->con->conectar()->prepare("DELETE FROM `produto` WHERE `idProduto` = :idProduto;");
            $cst->bindParam(":idProduto", $this->idProduto, PDO::PARAM_INT);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error'.$ex->getMessage();
        }
    }

}

?>
