<?php

require_once 'classes/Estoque.class.php';
require_once 'classes/Funcoes.class.php';

$objFcn = new Estoque();
$objFcs = new Funcoes();

if(isset($_POST['add']))
{    
    if($objFcn->queryInsert($_POST) == 'ok')
    {
        
            $con = new PDO('mysql:host=127.0.0.1:49277;dbname=localdb', 'azure', '6#vWHD_$');
            $stm = $con-> prepare('SELECT * FROM estoque
                                    INNER JOIN produto ON produto.idProduto = estoque.id_produto_estoque;');
            $stm-> execute();
            $result = $stm-> fetchAll(PDO::FETCH_ASSOC);
        
    }else{
        echo '<script type="text/javascript">alert("Erro em cadastrar");</script>';
    }
};?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>  
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/estilo.css">
    <title>Cadastrar estoque</title>
    <?php 
        session_start();
        if((!isset ($_SESSION['nome_colaborador']) == true) and (!isset ($_SESSION['senha_colaborador']) == true))
        {
            unset($_SESSION['nome_colaborador']);
            unset($_SESSION['senha_colaborador']);
            header('location:index.php');
            }
        $logado = $_SESSION['nome_colaborador'];?>
</head>

<body>
<div class="container-fluid">
    <div class="row">
        <div id="relatorio">
            <div class="card">
                <div class="card-header">
                    Estoque
                </div>
            <div class="card-body">
                <blockquote class="blockquote mb-0">
                    <div id="formulario">
                        <form method="post">
                            <div class="form-group">
                        	   <label>Produto:</label><br>
                                    <select id="id_produto_estoque" name="id_produto_estoque">
                                        <option value="">Selecione</option>
                                        <?php
                                            $conn = new PDO('mysql:host=127.0.0.1:49277;dbname=localdb', 'azure', '6#vWHD_$');
                                            $stmt = $conn-> prepare('SELECT idProduto, nome_produto FROM produto');
                                            $stmt-> execute();
                                            $res = $stmt-> fetchAll(PDO::FETCH_ASSOC);
                                            foreach($res as $row){?>
                                                <option value="<?php echo utf8_encode($row['idProduto']);?>"><?php echo utf8_encode($row['nome_produto']);?></option>
                                        <?php }?>
                                   </select>
                              </div>
                                <div class="form-group">                        	   
                                        <label>Quantidade:</label><br>
                                        <input type="text" class="form-group" name="quantidade_estoque" required="required" value="<?php echo $quantidade_estoque;?>" maxlength=4><br>
                                 </div>

                            <input type="hidden" name="colaborador_estoque" id="colaborador_estoque" value="<?php echo $_SESSION['nome_colaborador'];?>">
                          
                            <a href='site.php'><button type='button' class='btn btn-danger btn-sm'>Voltar</button></a>
                            <input type="submit" class="btn btn-primary btn-sm" name="add" value="add">
                    
                        </form>
                        </div>
                    </blockquote>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        </br>
    </div>
    <div class="row">
         <div id="relatorio">
           <div class="card">
                <div class="card-header">
                    Estoque cadastrado</br>
                </div>
            <div class="card-body">
                <blockquote class="blockquote mb-0">
                    <div class="estoque">
                        <table class="table table-hover">
                              <thead>
                                    <tr>
                                        <th scope="col" class="celula_fixa">Produto</th>
                                        <th scope="col" class="celula_fixa">Quantidade</th>
                                    </tr>
                              </thead>
                              <tbody>
                                    <?php
                                    foreach($result as $roww){?>
                                            <tr>
                                                <th scope="row" class="celula_fixa">
                                                    <?php echo utf8_encode($roww['nome_produto']);?>
                                                </th>
                                                <td class="celula_fixa">
                                                    <input name="quantidade_estoque" id="quantidade_estoque" value="<?php echo $roww['quantidade_estoque'];?>" style="width:22px;font-size: 13px; border:0;">
                                                </td>
                                                <td class="celula_fixa">
                                                    <div class="excluir">
                                                         <a href="?acao=delet&idEstoque=<?=$roww['idEstoque']?>" title="Excluir esse dado">
                                                             <img src="img/ico-excluir.png" width="16" height="16" alt="Excluir">
                                                        </a>
                                                     </div>
                                                </td>
                                            </tr>
                                    <?php } ?>
                              </tbody>
                            </table>
                        </div>
                      </blockquote>       
                    </div>
                </div>
            </div>
        </div>
</body>
</html>
