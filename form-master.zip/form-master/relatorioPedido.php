<?php

require_once 'classes/Pedido.class.php';
require_once 'classes/Funcoes.class.php';

$objFcn = new Pedido();
$objFcs = new Funcoes();

if(isset($_GET['acao'])){
    switch($_GET['acao']){
        case 'edit': $func = $objFcn->querySeleciona($_GET['idPedido']); 
            header("location: /pedido.php?idPedido=".$_GET['idPedido']."");
            break;
        case 'delet':
            if($objFcn->queryDelete($_GET['idPedido']) == 'ok'){
                header('location: /relatorioPedido.php');
            }else{
                echo '<script type="text/javascript">alert("Erro em deletar");</script>';
            }
                break;
        }
    }

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>  
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="css/estilo.css">
    <title>Cadastrar pedido</title>
    <?php 
        session_start();
        if((!isset ($_SESSION['nome_colaborador']) == true) and (!isset ($_SESSION['senha_colaborador']) == true))
        {
            unset($_SESSION['nome_colaborador']);
            unset($_SESSION['senha_colaborador']);
            header('location:index.php');
            }

        $logado = $_SESSION['nome_colaborador'];?>
</head>

<body>
<div class="media">
      <div class="media-body">
        <h5 class="mt-0 mb-1">Resturante</h5>
      </div>
        <?php echo"$logado";?>
      <img class="ml-3" src="img/usuario.png">
    </div>
      <nav class="navbar navbar-light" style="background-color: #e3f2fd;">
        <a class="navbar-brand" href="pedido.php">Novo Pedido</a>
      </nav>
    </div>

<div class="container-fluid">
    <div class="row">
    
    <div class="row">
         <div id="relatorio">
            <div class="card">
                <div class="card-header">
                    Pedidos cadastrados</br>
                </div>
            <div class="card-body">
                <blockquote class="blockquote mb-0">
        <div class="produto">
                    <table class="table table-hover">
                      <thead>
                        <tr>
                            <th scope="col">Numero do pedido</th>
                            <th scope="col">Cliente</th>
                            <th scope="col">Data/Hora</th>
                            <th scope="col">Registro</th>
                            <th scope="col">Editar</th>
                            <th scope="col">Excluir</th>
                        
                        </tr>
                      </thead>
                      <tbody>
                            <?php
                                    $con = new PDO('mysql:host=127.0.0.1:49277;dbname=localdb', 'azure', '6#vWHD_$');
                                    $stm = $con-> prepare("SELECT * FROM pedido;");
                                    $stm-> execute();
                                    $ress = $stm-> fetchAll(PDO::FETCH_ASSOC);
                            foreach($ress as $roww){?>
                                    <tr>
                                        <td><?=$roww['idPedido']?></td>
                                        <th scope="row">
                                            <?php
                                                $conn = new PDO('mysql:host=127.0.0.1:49277;dbname=localdb', 'azure', '6#vWHD_$');
                                                $stmt = $conn-> prepare("SELECT nome_cliente FROM cliente WHERE idCliente = ".$roww['idCliente'].";");
                                                $stmt-> execute();
                                                $res = $stmt-> fetchAll(PDO::FETCH_ASSOC);
                                                foreach($res as $row)
                                                {
                                                    echo utf8_encode($row['nome_cliente']);
                                                }
                                            ?></th>
                                        <td><?=$roww['data_hora_pedido']?></td>
                                        <td><?=$roww['registro_pedido']?></td>

                                        <td><div class="editar"><a href="?acao=edit&idPedido=<?=$roww['idPedido']?>" title="Editar dados"><img src="img/ico-editar.png" width="16" height="16" alt="Editar"></a></div></td>
                                        
                                        <td><div class="excluir"><a href="?acao=delet&idPedido=<?=$roww['idPedido']?>" title="Excluir esse dado"><img src="img/ico-excluir.png" width="16" height="16" alt="Excluir"></a></div></td>
                                    
                                    </tr>
                            <?php } ?>
                      </tbody>
                    </table>
        </div>
    </blockquote>       
            </div>
        </div>
        </div>
    </div>
</div>
</body>
</html>
