<?php

require_once 'classes/Produto.class.php';
require_once 'classes/Funcoes.class.php';

$objFcn = new Produto();
$objFcs = new Funcoes();

if(isset($_POST['btCadastrar'])){
    if($objFcn->queryInsert($_POST) == 'ok'){
        header('location: /produto.php');
    }else{
        echo '<script type="text/javascript">alert("Erro em cadastrar");</script>';
    }
}

if(isset($_POST['btAlterar'])){
    if($objFcn->queryUpdate($_POST) == 'ok'){
        header('location: ?acao=edit&idProduto='.$objFcs->base64($_POST['idProduto'],1));
    }else{
        echo '<script type="text/javascript">alert("Erro em alterar");</script>';
    }
}


if(isset($_GET['acao'])){
    switch($_GET['acao']){
        case 'edit': $func = $objFcn->querySeleciona($_GET['idProduto']); break;
        case 'delet':
            if($objFcn->queryDelete($_GET['idProduto']) == 'ok'){
                header('location: /produto.php');
            }else{
                echo '<script type="text/javascript">alert("Erro em deletar");</script>';
            }
                break;
    }
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>  
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
      <link rel="stylesheet" type="text/css" href="css/estilo.css">
    <title>Cadastrar produto</title>
    <?php 
        session_start();
        if((!isset ($_SESSION['nome_colaborador']) == true) and (!isset ($_SESSION['senha_colaborador']) == true))
        {
            unset($_SESSION['nome_colaborador']);
            unset($_SESSION['senha_colaborador']);
            header('location:index.php');
            }
         
        $logado = $_SESSION['nome_colaborador'];?>
</head>

<body>
<div class="container-fluid">
    <div class="row">
        <div id="relatorio">
            <div class="card">
                <div class="card-header">
                    Produto
                </div>
            <div class="card-body">
                <blockquote class="blockquote mb-0">
                    <div id="formulario">
                        <form name="formCad" action="" method="post">
                            <div class="form-group">
                        	   <label>Nome:</label><br>
                                <input type="text" class="form-group" name="nome_produto" required="required" value="<?=$objFcs->tratarCaracter((isset($func['nome_produto']))?($func['nome_produto']):(''), 2)?>"><br>
                            </div>
                            <div class="form-group">
                                <label>Valor: </label><br>
                                <input type="text" class="form-group" name="valor_produto" required="required" value="<?=$objFcs->tratarCaracter((isset($func['valor_produto']))?($func['valor_produto']):(''), 2)?>"><br>
                            </div>
                            <select name="grupo_produto">
                                <?php
                                    $conn = new PDO('mysql:host=127.0.0.1:49277;dbname=localdb', 'azure', '6#vWHD_$');
                                    $stmt = $conn-> prepare('SELECT nome_grupo FROM grupo');
                                    $stmt-> execute();
                                    $res = $stmt-> fetchAll(PDO::FETCH_ASSOC);
                                    foreach($res as $row){?>
                                <option value="<?php echo utf8_encode($row['nome_grupo']);?>"><?php echo utf8_encode($row['nome_grupo']);?></option>
                                <?php } ?>
                            </select>
                            <br>
                            <a href='site.php'><button type='button' class='btn btn-danger btn-sm'>Voltar</button></a>
                            <input type="submit" class="btn btn-primary btn-sm" name="<?=(isset($_GET['acao']) == 'edit')?('btAlterar'):('btCadastrar')?>" value="<?=(isset($_GET['acao']) == 'edit')?('Alterar'):('Cadastrar')?>">
                            <input type="hidden" name="idProduto" value="<?=(isset($func['idProduto']))?($objFcs->base64($func['idProduto'], 1)):('')?>">
                            <input type="hidden" name="colaborador_produto" value="<?=($logado)?>">

                            </form>
                        </div>
                    </blockquote>       
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        </br>
    </div>
    <div class="row">
         <div id="relatorio">
            <div class="card">
                <div class="card-header">
                    Produtos cadastrados
                </div>
            <div class="card-body">
                <blockquote class="blockquote mb-0">
        <div class="produto">
                    
                    <table class="table table-hover">
                      <thead>
                        <tr>
                            <th scope="col">Nome</th>
                            <th scope="col">Grupo</th>
                            <th scope="col">Valor</th>
                            <th scope="col">Editar</th>
                            <th scope="col">Apagar</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach($objFcn->querySelect() as $rst){ ?>
                            <tr>
                              <th scope="row"><div class="nome_produto"><?=$objFcs->tratarCaracter($rst['nome_produto'], 2)?></div></th>
                              <td><div class="grupo_produto"><?=$objFcs->tratarCaracter($rst['grupo_produto'], 2)?></div></td>
                              <td><div class="valor_produto"><?=$objFcs->tratarCaracter($rst['valor_produto'], 2)?></div></td>
                              <td><div class="editar"><a href="?acao=edit&idProduto=<?=$objFcs->base64($rst['idProduto'], 1)?>" title="Editar dados"><img src="img/ico-editar.png" width="16" height="16" alt="Editar"></a></div></td>
                              <td><div class="excluir"><a href="?acao=delet&idProduto=<?=$objFcs->base64($rst['idProduto'], 1)?>" title="Excluir esse dado"><img src="img/ico-excluir.png" width="16" height="16" alt="Excluir"></a></div></td>
                            </tr>
                        <?php } ?>
                        </tbody>
                    </table>
        </div>
    </blockquote>       
            </div>
        </div>
        </div>
    </div>
</div> 
</body>
</html>
