<?php 
session_start();
$nome_colaborador = $_POST['nome_colaborador'];
$senha_colaborador = $_POST['senha_colaborador'];
$con = mysql_connect("127.0.0.1:49277", "azure", "6#vWHD_$") or die ("Sem conexão com o servidor");
$select = mysql_select_db("localdb") or die("Sem acesso ao DB, Entre em contato com o Administrador, rodrigofurlaneti31@hotmail.com");
$result = mysql_query("SELECT * FROM `colaborador` WHERE `nome_colaborador` = '$nome_colaborador' AND `senha_colaborador`= '$senha_colaborador'");

if(mysql_num_rows ($result) > 0 )
{
	$_SESSION['nome_colaborador'] = $nome_colaborador;
	$_SESSION['senha_colaborador'] = $senha_colaborador;
	header('location:site.php');
}
else{
    unset ($_SESSION['nome_colaborador']);
    unset ($_SESSION['senha_colaborador']);
    header('location:areaErp.php');
    }
?>