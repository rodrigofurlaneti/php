<!DOCTYPE html>
<html lang="pt-BR">
<head>  
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
      <link rel="stylesheet" type="text/css" href="css/estilo.css">
    <title>Restaurante</title>
</head>
<body>
<body background="img/fundo.jpg" bgproperties="fixed">
<nav class="navbar navbar-light bg-light justify-content-between p-3 mb-2 bg-dark ">
  <a class="navbar-brand text-white">Restaurante</a>
    <form class="form-inline" method="post" action="opeCliente.php" id="formlogin" name="formlogin" >
            <div class="input-group input-group-sm mb-3">
              <input type="text" class="form-control" aria-describedby="inputGroup-sizing-sm" name="telefone_cliente" id="telefone_cliente" placeholder="Telefone">
            </div>
            <div class="input-group input-group-sm mb-3">
              <input type="text" class="form-control" aria-describedby="inputGroup-sizing-sm" name="senha_cliente" id="senha_cliente" placeholder="Senha">
            </div>
            <div class="input-group input-group-sm mb-3">
              <input type="submit" value="Entrar" class="btn btn-primary btn-sm">
            </div>
            <div class="input-group input-group-sm mb-3">
              <a href='novoCliente.php'><input type="button" value="Novo Cliente" class="btn btn-sucess btn-sm"></a>
            </div>
    </form>
</nav>

<div class="media">
  <img class="mr-3" src="img/pizza.png" alt="Generic placeholder image">
  <div class="media-body">
    <h5 class="mt-0">Pizza</h5>
Ingredientes garimpados, receitas inspiradas, hospitalidade em cada detalhe. Com 20 anos de história e o posto entre as 10 melhores pizzarias do mundo - em ranking dos jornais The Guardian e Corriere della Sera -, é uma pizzaria apaixonada por pizza, como você.
  </div>
</div>


<div class="media">
  <img class="mr-3" src="img/hamb.png" alt="Generic placeholder image">
  <div class="media-body">
    <h5 class="mt-0">Lanches</h5>
É uma refeição composta por pequena porção de alimentos, entre as refeições principais, geralmente entre o almoço e o jantar. Também pode ser chamado de merenda ou café da tarde. O lanche serve para saciar temporariamente a fome de uma pessoa, prover uma pequena quantidade de energia ou mesmo apenas para satisfazer o paladar. Dentre os principais alimentos dessas refeições, podem-se elencar os bolos, sanduíches, chás e cafés.
  </div>
</div>

<div class="media">
  <img class="mr-3" src="img/batata.png" alt="Generic placeholder image">
  <div class="media-body">
    <h5 class="mt-0">Batata</h5>
A tão sonhada batata frita crocante e sequinha não é impossível. Com os utensílios corretos e alguns truques, é possível prepará-la de forma fácil, garantindo um resultado saboroso e nada encharcado de gordura.
  </div>
</div>

<div class="media">
  <img class="mr-3" src="img/esfiha.png" alt="Generic placeholder image">
  <div class="media-body">
    <h5 class="mt-0">Esfiha</h5>
É uma pequena torta assada originária da Síria e do Líbano, e encontrada em outros países do Oriente Médio, como a Jordânia, Palestina e Iraque, além do Brasil e Argentina, para onde foi levada por imigrantes sírios e libaneses e se tornou extremamente popular. Existem diversas receitas de esfiha. A forma tradicional sempre é feita com massa de pão, assada no forno, com recheios que podem ser de carne bovina, carne de carneiro, queijo, coalhada ou verduras temperadas.
  </div>
</div>

<div class="media">
  <img class="mr-3" src="img/coca.png" alt="Generic placeholder image">
  <div class="media-body">
    <h5 class="mt-0">Refrigerante</h5>
Bebida que refresca; refresco gelado, bebida não alcoólica, gasosa, de sabor adocicado, industrializada e vendida em garrafas e latas.
  </div>
</div>

<div class="media">
  <img class="mr-3" src="img/cerveja.png" alt="Generic placeholder image">
  <div class="media-body">
    <h5 class="mt-0">Cerveja</h5>
É uma bebida produzida a partir da fermentação de cereais, principalmente a cevada maltada. Acredita-se que tenha sido uma das primeiras bebidas alcoólicas que foram criadas pelo ser humano. Atualmente, é a terceira bebida mais popular do mundo, logo depois da água e do café. É a bebida alcoólica mais consumida no mundo atualmente.
  </div>
</div>

<div class="media">
  <img class="mr-3" src="img/ref.png" alt="Generic placeholder image">
  <div class="media-body">
    <h5 class="mt-0">Refeição</h5>
É uma porção de alimentos consumida de uma vez a fim de garantir o sustento de um ser humano por uma grande quantidade horas. Embora cada nutricionista tenha sua opinião sobre o assunto, em geral, eles aconselham a realização de, pelo menos, três refeições diárias: o pequeno-almoço (desjejum), almoço e jantar, podendo ou não ser completadas com lanches nos intervalos entre cada uma (não se devendo passar mais de 3 horas e meia sem se comer).
  </div>
</div>
  <nav class="navbar navbar-light bg-light justify-content-between p-3 mb-2 bg-dark">
    <ul class="nav justify-content-end">
      <li> 
      </li>
    </ul>
    <a href='areaErp.php'><button type='button' class='btn btn-danger btn-sm'>Sistema</button></a>
  </nav>
</body>
</html>
