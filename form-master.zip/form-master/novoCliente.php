<?php

require_once 'classes/Cliente.class.php';
require_once 'classes/Funcoes.class.php';

$objFcn = new Cliente();
$objFcs = new Funcoes();

if(isset($_POST['btCadastrar'])){
    if($objFcn->queryInsert($_POST) == 'ok'){
        header('location: /index.php');
    }else{
        echo '<script type="text/javascript">alert("Erro em cadastrar");</script>';
    }
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>  
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
      <link rel="stylesheet" type="text/css" href="css/estilo.css">
    <title>Cadastrar novo cliente</title>
</head>

<body>
<div class="container-fluid">
    <div class="row">
        <div id="relatorio">
            <div class="card">
                <div class="card-header">
                    Cliente
                </div>
            <div class="card-body">
                <blockquote class="blockquote mb-0">
                    <div id="formulario">
                        <form name="formCad" action="" method="post">
                            <div class="form-group">
                        	   <label>Nome:</label><br>
                                <input type="text" class="form-group" name="nome_cliente" required="required" value="<?=$objFcs->tratarCaracter((isset($func['nome_cliente']))?($func['nome_cliente']):(''), 2)?>"><br>
                            </div>
                            <div class="form-group">
                                <label>Endereço: </label><br>
                                <input type="text" class="form-group" name="endereco_cliente" required="required" value="<?=$objFcs->tratarCaracter((isset($func['endereco_cliente']))?($func['endereco_cliente']):(''), 2)?>"><br>
                            </div>
                            <div class="form-group">
                                <label>Telefone: </label><br>
                                <input type="text" class="form-group" name="telefone_cliente" required="required" value="<?=$objFcs->tratarCaracter((isset($func['telefone_cliente']))?($func['telefone_cliente']):(''), 2)?>"><br>
                            </div>
                            <div class="form-group">
                                <label>Senha: </label><br>
                                <input type="password" class="form-group" name="senha_cliente" required="required" value="<?=$objFcs->tratarCaracter((isset($func['senha_cliente']))?($func['senha_cliente']):(''), 2)?>"><br>
                            </div>
                            <a href='site.php'><button type='button' class='btn btn-danger btn-sm'>Voltar</button></a>
                            <input type="submit" class="btn btn-primary btn-sm" name="btCadastrar" value="Cadastrar">
                            <input type="hidden" name="idCliente" value="<?=(isset($func['idCliente']))?($objFcs->base64($func['idCliente'], 1)):('')?>">
                            <input type="hidden" name="colaborador_cliente" value="<?=($logado)?>">

                            </form>
                        </div>
                    </blockquote>       
                </div>
            </div>
        </div>
    </div>

</div> 
</body>
</html>
