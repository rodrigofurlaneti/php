<?php

require_once 'classes/Pedido.class.php';
require_once 'classes/Funcoes.class.php';

$objFcn = new Pedido();
$objFcs = new Funcoes();

if(isset($_POST['idCliente']))
{
    if($objFcn->queryInsert($_POST) == 'ok')
    {
        $conn = new PDO('mysql:host=127.0.0.1:49277;dbname=localdb', 'azure', '6#vWHD_$');
        $stmt = $conn-> prepare('SELECT pedido.idPedido, pedido.idCliente, cliente.nome_cliente 
                                FROM pedido 
                                INNER JOIN cliente ON cliente.idCliente = pedido.idCliente 
                                ORDER BY idPedido DESC LIMIT 1;');
        $stmt-> execute();
        $res = $stmt-> fetchAll(PDO::FETCH_ASSOC);
        foreach($res as $row)
        {
            $idPedido = $row['idPedido'];
            $idCliente = $row['idCliente'];
            $pedido['nome_cliente'] = $row['nome_cliente'];
        }
            
    }
}


if(isset($_POST['add']))
{    
    if($objFcn->queryInsertPedidoItem($_POST) == 'ok')
    {
   
        $valor_unid = 0;
        $quant = 0;
        
        $connn = new PDO('mysql:host=127.0.0.1:49277;dbname=localdb', 'azure', '6#vWHD_$');
        $stmtt = $connn-> prepare('SELECT   pedidoitem.idPedido_pedidoitem, pedidoitem.data_hora_pedidoitem, 
                                            pedidoitem.id_produto_pedidoitem, pedidoitem.quantidade_pedidoitem,
                                            pedido.idPedido, pedido.idCliente,
                                            cliente.nome_cliente, 
                                            produto.nome_produto, produto.valor_produto
                                            FROM pedido 
                                            INNER JOIN cliente ON cliente.idCliente = pedido.idCliente 
                                            INNER JOIN pedidoitem ON pedidoitem.id_pedido_pedidoitem = pedido.idPedido 
                                            INNER JOIN produto 
                                            ORDER BY pedidoitem.idPedido_pedidoitem DESC LIMIT 1;');
        $stmtt-> execute();
        $resss = $stmtt-> fetchAll(PDO::FETCH_ASSOC);
        foreach($resss as $rowww)
        {
            $pedidoitem = $rowww['idPedido_pedidoitem'];
            $idPedido = $rowww['idPedido'];
            $idCliente = $rowww['idCliente'];
            $pedido['nome_cliente'] = $rowww['nome_cliente'];
            $valor_unid = $rowww['valor_produto'];
            $quant = $rowww['quantidade_pedidoitem'];
            $nome_produto = $rowww['nome_produto'];
            
        }
        if ($_SERVER['REQUEST_METHOD'] == 'POST')
        {
            $valor_parcial = 0;
            $valor_parcial = intval($valor_unid) * intval($quant);

        }
     
            $connn = new PDO('mysql:host=127.0.0.1:49277;dbname=localdb', 'azure', '6#vWHD_$');
            $stmtt = $connn-> prepare('UPDATE `pedidoitem` SET  `valor_parcial_pedidoitem` = '.$valor_parcial.' WHERE `idPedido_pedidoitem` =  '.$pedidoitem.';');
            $stmtt-> execute();

            $con = new PDO('mysql:host=127.0.0.1:49277;dbname=localdb', 'azure', '6#vWHD_$');
            $stm = $con-> prepare('SELECT   produto.nome_produto, produto.valor_produto, 
                                            pedidoitem.quantidade_pedidoitem, pedidoitem.valor_parcial_pedidoitem, pedidoitem.idPedido_pedidoitem, pedidoitem.data_hora_pedidoitem 
                                            FROM pedido 
                                            INNER JOIN pedidoitem ON pedidoitem.id_pedido_pedidoitem = pedido.idPedido 
                                            INNER JOIN produto ON produto.idProduto = pedidoitem.id_produto_pedidoitem 
                                            WHERE pedido.idPedido = '.$idPedido.';');
            $stm-> execute();
            $result = $stm-> fetchAll(PDO::FETCH_ASSOC);
        
    }else{

        echo '<script type="text/javascript">alert("Erro em cadastrar");</script>';
    }
};?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>  
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/estilo.css">
    <title>Cadastrar pedido</title>
    <?php 
        session_start();
        if((!isset ($_SESSION['nome_colaborador']) == true) and (!isset ($_SESSION['senha_colaborador']) == true))
        {
            unset($_SESSION['nome_colaborador']);
            unset($_SESSION['senha_colaborador']);
            header('location:index.php');
            }

        $logado = $_SESSION['nome_colaborador'];?>
</head>

<body>
<div class="container-fluid">
    <div class="row">
        <div id="relatorio">
            <div class="card">
                <div class="card-header">
                    Pedido
                </div>
            <div class="card-body">
                <blockquote class="blockquote mb-0">
                    <div id="formulario">
                        <form method="post">
                            <div class="form-group">
                        	   <label>Cliente:</label><br>
                                    <select id="idCliente" name="idCliente" onchange="this.form.submit()">
                                        <option value="">Selecione</option>
                                        <?php
                                            $conn = new PDO('mysql:host=127.0.0.1:49277;dbname=localdb', 'azure', '6#vWHD_$');
                                            $stmt = $conn-> prepare('SELECT idCliente, nome_cliente FROM cliente');
                                            $stmt-> execute();
                                            $res = $stmt-> fetchAll(PDO::FETCH_ASSOC);
                                            foreach($res as $row){?>
                                                <option value="<?php echo utf8_encode($row['idCliente']);?>"><?php echo utf8_encode($row['nome_cliente']);?></option>
                                        <?php }?>
                                   </select>
                            </div>
                            <input type="hidden" name="valor_total_pedido" value="0">
                            <input type="hidden" name="data_hora_pedido" value="<?php echo date('d/m/Y h:i:sa');?>">
                            <input type="hidden" name="registro_pedido" value="<?php echo $_SESSION['nome_colaborador'];?>">
                            <noscript><input type="submit" value="idCliente"></noscript>
                        </form>
                    </div>

                    <div id="formulario">
                        <form method="post">
                            <input type="hidden" name="id_pedido_pedidoitem" value="<?php echo $idPedido?>">
                            <div class="form-group">
                                <label>Produto: </label><br>
                                <select name="id_produto_pedidoitem">
                                    <option value="">Selecione</option>
                                    <?php
                                        $conn = new PDO('mysql:host=127.0.0.1:49277;dbname=localdb', 'azure', '6#vWHD_$');
                                        $stmt = $conn-> prepare('SELECT idProduto, nome_produto FROM produto');
                                        $stmt-> execute();
                                        $res = $stmt-> fetchAll(PDO::FETCH_ASSOC);
                                        foreach($res as $row){?>
                                    <option value="<?php echo utf8_encode($row['idProduto']);?>"><?php echo utf8_encode($row['nome_produto']);?></option>
                                    <?php } ?>
                                </select>
                            </div>

                            <div class="form-group">
                               <label>Quantidade:</label><br>
                                <input type="text" class="form-group" name="quantidade_pedidoitem" required="required" value="<?=($quantidade_pedidoitem)?>" maxlength=4><br>
                            </div>
                            
                            <input type="hidden" name="valor_parcial_pedidoitem">
                            
                            <input type="hidden" name="solicitante_pedidoitem" value="<?php echo $_SESSION['nome_colaborador'];?>">

                            <input type="hidden" name="data_hora_pedidoitem" value="<?php echo date('d/m/Y h:i:sa');?>">
                            
                            <a href='site.php'><button type='button' class='btn btn-danger btn-sm'>Voltar</button></a>
                            <input type="submit" class="btn btn-primary btn-sm" name="<?=(isset($_GET['idPedido']) <> '')?('alterar'):('add')?>" value="<?=(isset($_GET['idPedido']) <> '')?('alterar'):('add')?>">
                    
                        </form>
                    </div>
                    </blockquote>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        </br>
    </div>
    <div class="row">
         <div id="relatorio">
            <div class="card">
                <div class="card-header">
                    Pedidos cadastrados</br>
                <?php echo $idPedido;?>            
                </div>
            <div class="card-body">
                <blockquote class="blockquote mb-0">
        <div class="produto">
        <?php echo utf8_encode($pedido['nome_cliente']);
        ?>
                    <table class="table table-hover">
                      <thead>
                        <tr>
                            <th scope="col" class="celula_fixa">Produto</th>
                            <th scope="col" class="celula_fixa">Valor Unitário</th>
                            <th scope="col" class="celula_fixa">Quantidade</th>
                            <th scope="col" class="celula_fixa">Valor Parcial</th>
                        </tr>
                      </thead>
                      <tbody>
                            <?php
                            foreach($result as $roww){?>
                                    
                                    <tr>
                                        
                                        <th scope="row" class="celula_fixa">
                                            <?php echo utf8_encode($roww['nome_produto']);?></th>
                                                    <td>                                              
                                                        <input name="valor_produto" id="valor_produto" value="<?php echo $roww['valor_produto'];?>" style="width:22px;font-size: 13px; border:0;">
                                                    </td>
                                        
                                        <td class="celula_fixa">
                                            <input name="quantidade_pedidoitem" id="quantidade_pedidoitem" value="<?php echo $roww['quantidade_pedidoitem'];?>" style="width:22px;font-size: 13px; border:0;"></td>
                                        
                                        <td class="celula_fixa">
                                            <input name="valor_parcial_pedidoitem" id="valor_parcial_pedidoitem" value="<?php echo $roww['valor_parcial_pedidoitem'];?>" style="width:22px;font-size: 13px; border:0;">
                                        </td>

                                        <td class="celula_fixa">
                                            <div class="excluir"><a href="?acao=delet&id_pedido_pedidoitem=<?=$roww['idPedido_pedidoitem']?>" title="Excluir esse dado"><img src="img/ico-excluir.png" width="16" height="16" alt="Excluir"></a></div></td>
                                    </tr>

                            <?php } ?>

                      </tbody>
                    </table>

            <label>Valor Total</label>
        </div>
    </blockquote>       
            </div>
        </div>
        </div>
    </div>
</div>
</body>
</html>
