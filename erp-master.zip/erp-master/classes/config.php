<?php

define('DB_HOST', '127.0.0.1:50143');
define('DB_NAME', 'localdb');
define('DB_USER', 'azure');
define('DB_PASS', '6#vWHD_$');

