<?php

require_once 'Crud.php';

class Cliente extends Crud{
	
	protected $table = 'cliente';
	private $id;
	private $nome_cliente;
	private $endereco_cliente;
	private $telefone_cliente;
	private $senha_cliente;
	private $colaborador_cliente;

	// NOME_CLIENTE
	public function setNomeCliente($nome_cliente){
		$this->nome_cliente = $nome_cliente;
	}

	public function getNomeCliente(){
		return $this->nome_cliente;
	}

	// ENDEREÇO CLIENTE
	public function setEnderecoCliente($endereco_cliente){
		$this->endereco_cliente = $endereco_cliente;
	}

	public function getEnderecoCliente(){
		return $this->endereco_cliente;
	}

	// ENDEREÇO CLIENTE
	public function setTelefoneCliente($telefone_cliente){
		$this->telefone_cliente = $telefone_cliente;
	}

	public function getTelefoneCliente(){
		return $this->telefone_cliente;
	}

	// SENHA CLIENTE
	public function setSenhaCliente($senha_cliente){
		$this->senha_cliente = $senha_cliente;
	}

	public function getSenhaCliente(){
		return $this->senha_cliente;
	}

	// COLABORADOR CLIENTE
	public function setColaboradorCliente($colaborador_cliente){
		$this->colaborador_cliente = $colaborador_cliente;
	}

	public function getSenhaCliente(){
		return $this->colaborador_cliente;
	}

	public function insert(){

		$sql  = "INSERT INTO $this->table (nome_cliente, endereco_cliente, telefone_cliente, senha_cliente, colaborador_cliente) VALUES (:nome_cliente, :endereco_cliente, :telefone_cliente, :senha_cliente, :colaborador_cliente)";
		$stmt = DB::prepare($sql);
		$stmt->bindParam(':nome_cliente', $this->nome_cliente);
		$stmt->bindParam(':endereco_cliente', $this->endereco_cliente);
		$stmt->bindParam(':telefone_cliente', $this->telefone_cliente);
		$stmt->bindParam(':senha_cliente', $this->senha_cliente);
		$stmt->bindParam(':colaborador_cliente', $this->colaborador_cliente);
		return $stmt->execute(); 

	}

	public function update($id){

		$sql  = "UPDATE $this->table SET nome_cliente = :nome_cliente, endereco_cliente = :endereco_cliente, telefone_cliente = :telefone_cliente, senha_cliente = :senha_cliente, colaborador_cliente = :colaborador_cliente WHERE id = :id";
		$stmt = DB::prepare($sql);
		$stmt->bindParam(':nome_cliente', $this->nome_cliente);
		$stmt->bindParam(':endereco_cliente', $this->endereco_cliente);
		$stmt->bindParam(':telefone_cliente', $this->telefone_cliente);
		$stmt->bindParam(':senha_cliente', $this->senha_cliente);
		$stmt->bindParam(':colaborador_cliente', $this->colaborador_cliente
		$stmt->bindParam(':id', $id);
		return $stmt->execute();

	}

}